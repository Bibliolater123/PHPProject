<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Contact</title>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <link href="css/style.css" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="css/menu_bar.css">
  <link rel="stylesheet" href="css/logo.css">
  <link rel="stylesheet" href="css/style_main.css">
  <link rel="stylesheet" href="including/Heart_ani/heart.css">
  <link rel="stylesheet" href="css/bag.css">
  <!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
  <script type="text/javascript" src="js/cufon-yui.js"></script>
  <script type="text/javascript" src="js/arial.js"></script>
  <script type="text/javascript" src="js/cuf_run.js"></script>
  <!-- CuFon ends -->

  <?php
  error_reporting(1);
  include("dbconnect.php");
  if (isset($_REQUEST['send'])) {
    $eadd = $_REQUEST['eadd'];
    $ph = $_REQUEST['ph'];
    $msg = $_REQUEST['msg'];
    $check = mysql_query("SELECT email FROM sign_up WHERE email='$eadd'");
    $run = mysql_fetch_array($check);
    if ($eadd == $run['email']) {
      mysql_query("INSERT INTO feedback VALUES('$eadd', '$ph', '$msg')");
      header('location:fbsent.php');
    } else {
      $error = "Email does not match!";
    }
  }
  ?>
  <style>
    .mainbar p {
      font-size: 16px;
    }
  </style>
</head>

<body>
  <div class="main">

    <div class="header">
      <div class="header_resize">
      <div class="menu-bar">
          <div class="menu_position">
            <ul>
              <li style="--clr:#030000"><a href="index.php" data-text="&nbsp;online shop">
              &nbsp;online shop&nbsp;
    </a> <!-- logo --></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <li style="--clr:#00ade1"><a href="index.php" data-text="&nbsp;Home">&nbsp;Home&nbsp;</a></li>
              <li style="--clr:#f11313"><a href="about.php" data-text="&nbsp;About Us">&nbsp;About Us&nbsp;</a></li>
              <li style="--clr:#ffdd1c"><a href="product.php" data-text="&nbsp;Products">&nbsp;Products&nbsp;</a></li>
              <li style="--clr:#dc00d4"><a class="active" style="font-size:1.2em;" href="contact.php" data-text="&nbsp;Contact Us">&nbsp;Contact Us&nbsp;</a></li>
              <li style="--clr:#06d406"><a href="signup.php" data-text="&nbsp;Register">&nbsp;Register&nbsp;</a></li>
              <li style="--clr:#5613f1"><a href="index.php" href="login.php" data-text="&nbsp;Log in">&nbsp;Log In&nbsp;</a></li>
              <li style="--clr:#13d0f1"><a href="index.php" data-text="&nbsp;Log Out">&nbsp;Log Out&nbsp;</a></li>
            </ul>
          </div>
        </div> <!-- menu-bar -->
        <div class="clr"></div>
        <div class="mainBox">
          <div class="smallBox"></div>
          <h2><a href="index.php"><span style="--clr:#00ade1">L</span><span style="--clr:#f11313">i</span><span style="--clr:#ffdd1c">t</span><span style="--clr:#dc00d4">t</span><span style="--clr:#06d406">l</span><span style="--clr:#5613f1">e</span></a></h2>
        </div>
        <a href="index.php">
          <h3>online shop</h3>
        </a>
        <div class="clr"></div>

        <?php
        error_reporting(1);
        include("including/index1.html");
        ?>
        <div class="img_resize">
          <img src="images/walking.png" alt="image" style="float:left;" />
          <div class="paper-dangling">
            <img src="images/shopping_bags.png" alt="" height="120px" width="120px">
          </div>
          <?php

          error_reporting(1);
          include("anishoe.html");

          ?>
        </div>
        <div class="clr"></div>
      </div>
    </div>

    <div class="content">
      <div class="content_resize">
        <div class="contact">
          <h2>Contact</h2>

          <div class="Heart">
            <div class="heart"></div>
          </div>


          
          <div id="contact-form">
            <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Welcome to our online store where you can find everything you need at unbeatable prices!
              Our contact details are as follows:</p><br><br><br>
              <form method="post">
                <table cellpadding="10px">
                  <tr>
                    <td colspan="2"><?php echo "<font color='red' size='4'>" . $error . "</font>"; ?></td>
                  </tr>
                  <tr>
                    <td>&nbsp;&nbsp;Email Address</td>
                    <td><input type="text" name="eadd" size="30" required></td>
                  </tr>
                  <tr>
                    <td>&nbsp;&nbsp;Phone Number</td>
                    <td><input type="text" name="ph" size="30" required></td>
                  </tr>
                  <tr>
                    <td>&nbsp;&nbsp;Your message</td>
                    <td><textarea name="msg" rows="10" cols="24" required></textarea></td>
                  </tr>
                  <tr>
                    <td colspan="2" align="center"><input class="submit" type="submit" name="send" value="Send">                                                                       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <input type="submit" class="break" value="Cancel">
                    </td>
                  </tr>
                </table>
              </form>
          </div>
            


        </div>

        <details>
          <summary></summary>
          <p><strong>Email:</strong><a href="">customerservice@littleshop.com</a><br>
            <strong>Phone:</strong>+1 (555) 123-4567 <br>
            <strong>Address:</strong>1234 Little Street, Littletown, USA<br>

            Our customer service representatives are available 24/7 to assist with any questions or concerns you may have.
            Whether you need help with placing an order, tracking your package, or returning an item, we are here to help!
            Don't hesitate to reach out to us for assistance. We look forward to hearing from you soon!
          </p>
        </details>

        <p>If you have any suggestion or feedback, please complete the following form. But need to have a member account.
          You can create your member account <a href="signup.php">here</a></p>

        <div class="clr"></div>
      </div>
    </div>

    <div class="media">
    <div class="media_resize" style="--m_r_c:#dc00d4">
      <div class="col group1">
        <div class="media_head" style="--m_h_c:#e991e6">
          <div class="media_title">
            <span style="left:20px;" style="--clr:#dc00d4;" data-text="About"><a href="about.php">About</a></span>
            <span style="--clr:#dc00d4;" data-text="Us"><a href="about.php">Us</a></span>
          </div>
        </div><br>
        <img src="images/art1.webp" width="56" height="56" alt="pix" />
        <p align="justify">Welcome to our online boots shop, where you will find a wide selection of high-quality boots
          that are perfect for any occasion. From stylish ankle boots to practical walking boots, our collection has
          been carefully curated to bring you the best in comfort, style, and durability.
          <a href="about.php"> Read More...</a>
        </p>
      </div>
      <div class="col group2">
      <div class="media_head" style="--m_h_c:#e991e6">
          <div class="media_title">
            <span style="left:20px;" style="--clr:#dc00d4;" data-text="Follow"><a href="fbsent.php">Follow</a></span>
            <span style="--clr:#dc00d4;" data-text="Us"><a href="fbsent.php">Us</a></span>
          </div>
        </div><br>
        <a href="#"><img style="--i_h:#dc00d4;" src="images/facebook.png" width="40" height="40" alt="ad" class="ad" /></a>
        <a href="#"><img style="--i_h:#dc00d4;" src="images/twitter.png" width="40" height="40" alt="ad" class="ad" /></a>
        <a href="#"><img style="--i_h:#dc00d4;" src="images/telegram.png" width="40" height="40" alt="ad" class="ad" /></a>
        <a href="#"><img style="--i_h:#dc00d4;" src="images/insta.png" width="40" height="40" alt="ad" class="ad" /></a>
      </div>
      <div class="col group3">
      <div class="media_head" style="--m_h_c:#e991e6">
          <div class="media_title">
            <span style="left:20px;" style="--clr:#dc00d4;" data-text="Contact"><a href="contact.php">Contact</a></span>
            <span style="--clr:#dc00d4;" data-text="Us"><a href="contact.php">Us</a></span>
          </div>
        </div><br>
        <p>Welcome to our online store where you can find everything you need at unbeatable prices!
          Click here to <a href="contact.php">Our contact details</a><br>

        </p>
      </div>
    </div>
  </div>

  <script type="text/javascript">
    const buttons = document.querySelectorAll('.break');
    buttons.forEach(btn => {
      btn.addEventListener('click', function (e) {
        e.preventDefault(); // Prevent the default navigation behavior

        let x = e.clientX - e.target.offsetLeft;
        let y = e.clientY - e.target.offsetTop;

        let container = document.createElement('div');
        container.classList.add('click_bubble');
        container.style.left = x + 'px';
        container.style.top = y + 'px';

        this.appendChild(container);

        setTimeout(() => {
          container.remove();
          if (this.tagName === 'INPUT') {
            // If the clicked element is an input, programmatically submit the form
            this.closest('form').submit();
          } else {
            // Otherwise, navigate to the target URL after the animation
            window.location.href = this.href;
          }
        }, 1000); // Wait for 1 seconds (1000 milliseconds)
      });
    });
  </script>
  
</body>

</html>