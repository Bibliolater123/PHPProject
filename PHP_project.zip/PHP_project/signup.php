<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Create Account</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/menu_bar.css">
<link rel="stylesheet" href="css/logo.css">
<link rel="stylesheet" href="css/bag.css">
<link rel="stylesheet" href="css/signup.css">
<!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/arial.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>
<!-- CuFon ends -->

<?php
error_reporting(1);

include("dbconnect.php");

$fname = $_REQUEST['f'];
$lname = $_REQUEST['l'];
$eid = $_REQUEST['eid'];
$pass = $_REQUEST['pwd'];
$ph = $_REQUEST['phno'];
$gen = $_REQUEST['r1'];
$day = $_REQUEST['d'];
$month = $_REQUEST['m'];
$year = $_REQUEST['y'];
$dob = $day . "/" . $month . "/" . $year;
$coun = $_REQUEST['coun'];
$city = $_REQUEST['city'];
$tsp = $_REQUEST['tsp'];
$noti = $_REQUEST['r2'];

if (isset($_REQUEST['reg'])) {
    $eid = mysql_real_escape_string($eid);
    $sql = mysql_query("SELECT * FROM sign_up WHERE email='$eid'");
    $arr = mysql_fetch_array($sql);
    if ($arr['email'] != $eid) {
        $fname = mysql_real_escape_string($fname);
        $lname = mysql_real_escape_string($lname);
        $pass = mysql_real_escape_string($pass);
        $ph = mysql_real_escape_string($ph);
        $gen = mysql_real_escape_string($gen);
        $dob = mysql_real_escape_string($dob);
        $coun = mysql_real_escape_string($coun);
        $city = mysql_real_escape_string($city);
        $tsp = mysql_real_escape_string($tsp);
        $noti = mysql_real_escape_string($noti);
        
        if (mysql_query("INSERT INTO sign_up VALUES('$fname','$lname','$eid','$pass','$ph','$gen','$dob','$coun','$city','$tsp','$noti')")) {
            echo "<script>location.href='signup_success.php?first=$fname&last=$lname&wel=$eid'</script>";
        }
    } else {
        echo "<h3 class='error'>User already exists</h3>";
    }
}
?>

<script>
	function fname()
	{
		var fname=/^[a-zA-Z]{3,15}$/;
		if(document.f1.f.value.search(fname)==-1)
		{
			alert("Your name must be alphabet!");
			document.f1.f.focus();
			return false;
		}
	} 
	function lname()
	{
		var lname=/^[a-zA-Z]{3,15}$/;
		if(document.f1.l.value.search(lname)==-1)
		{
			alert("Your name must be alphabet!");
			document.f1.l.focus();
			return false;
		}
	} 
	function email()
	{
		var email=/^[a-zA-Z0-9-_\.]+@[a-zA-Z]+\.[a-zA-Z]{2,3}$/;
		if(document.f1.eid.value.search(email)==-1)
		{
			alert("Please enter valid email! Like 'example@gmail.com'");
			document.f1.eid.focus();
			return false;
		}
	} 
	function pass()
	{
		var pass=/^[a-zA-Z0-9-_]{6,16}$/;
		if(document.f1.pwd.value.search(pass)==-1)
		{
			alert("Your password should be alphabet with numbers.");
			document.f1.pwd.focus();
			return false;
		}
	}
	function phone()
	{
		var phn=/^[0-9]{9,14}$/;
		if(document.f1.phno.value.search(phn)==-1)
		{
			alert("Invalid phone number! Please enter correct phone number.");
			document.f1.phno.focus();
			return false;
		}
	}
	
	function vali()
	{
		var name=/^[a-zA-Z]{3,15}$/;
		var email=/^[a-zA-Z0-9-_\.]+@[a-zA-Z]+\.[a-zA-Z]{2,3}$/;
		var pass=/^[a-zA-Z0-9-_]{6,16}$/;
	 	var phn=/^[0-9]{9,14}$/;
		if((document.f1.f.value.search(name)==-1)||(document.f1.f.value==""))
		{
			alert("Please check your first name field!");
			document.f1.f.focus();
			return false;
		}
		else if((document.f1.l.value.search(name)==-1)||(document.f1.l.value==""))
		{
			alert("Please check your last name field!");
			document.f1.l.focus();
			return false;
		}
		else if((document.f1.eid.value.search(email)==-1)||(document.f1.eid.value==""))
		{
			alert("Please check your email!");
			document.f1.eid.focus();
			return false;
		}
		else if((document.f1.pwd.value.search(pass)==-1)||(document.f1.pwd.value==""))
		{
			alert("Please check your password!");
			document.f1.pwd.focus();
			return false;
		}
		else if((document.f1.phno.value.search(phn)==-1)||(document.f1.phno.value==""))
		{
			alert("Please check your phone number!");
			document.f1.phno.focus();
			return false;
		}
		else if(document.f1.coun.value=="")
		{
			alert("Please fill your country");
			document.f1.coun.focus();
			return false;
		}
		else if(document.f1.city.value=="")
		{
			alert("Please fill your city");
			document.f1.city.focus();
			return false;
		}
		else if(document.f1.tsp.value=="")
		{
			alert("Please fill your township");
			document.f1.tsp.focus();
			return false;
		}
		else 
		{
			return true;
		}
	}
</script>

</head>

<body>
<div class="main">

  <div class="header">
    <div class="header_resize">
	<div class="menu-bar">
          <div class="menu_position">
            <ul>
              <li style="--clr:#030000"><a href="index.php" data-text="&nbsp;online shop">
              &nbsp;online shop&nbsp;
    </a> <!-- logo --></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <li style="--clr:#00ade1"><a href="index.php" data-text="&nbsp;Home">&nbsp;Home&nbsp;</a></li>
              <li style="--clr:#f11313"><a href="about.php" data-text="&nbsp;About Us">&nbsp;About Us&nbsp;</a></li>
              <li style="--clr:#ffdd1c"><a href="product.php" data-text="&nbsp;Products">&nbsp;Products&nbsp;</a></li>
              <li style="--clr:#dc00d4"><a href="contact.php" data-text="&nbsp;Contact Us">&nbsp;Contact Us&nbsp;</a></li>
              <li style="--clr:#06d406"><a class="active" style="font-size:1.2em;" href="index.php" href="signup.php" data-text="&nbsp;Register">&nbsp;Register&nbsp;</a></li>
              <li style="--clr:#5613f1"><a href="login.php" data-text="&nbsp;Log in">&nbsp;Log In&nbsp;</a></li>
              <li style="--clr:#13d0f1"><a href="index.php" data-text="&nbsp;Log Out">&nbsp;Log Out&nbsp;</a></li>
            </ul>
          </div>
        </div> <!-- menu-bar -->
	  <div class="clr"></div>
    <div class="mainBox">
      <div class="smallBox"></div>
      <h2><a href="index.php"><span style="--clr:#00ade1">L</span><span style="--clr:#f11313">i</span><span style="--clr:#ffdd1c">t</span><span style="--clr:#dc00d4">t</span><span style="--clr:#06d406">l</span><span style="--clr:#5613f1">e</span></a></h2>
    </div> 
  <a href="index.php"><h3>online shop</h3></a>
      <div class="clr"></div>

<?php
  error_reporting(1);
  include("including/index1.html");
?>

<div class="img_resize">
    <img src="images/walking.png" alt="image" style="float:left;" />
	<div class="paper-dangling">
      <img src="images/shopping_bags.png" alt="" height="120px" width="120px">
    </div>
    <?php

error_reporting(1);
include("anishoe.html");

?>
  </div>
  <div class="clr"></div>
    </div>
  </div>




  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2>Create your account!!</h2>
			<form method="post" name="f1" onsubmit="return vali()">
				<table border="0" cellpadding="15px" style="font-size:16px; font-weight:bold;" align="center">
					<tr>
						<td>First Name</td>
						<td><input type="text" name="f" onchange="return fname()"></td>
					</tr>
					<tr>
						<td>Last Name</td>
						<td><input type="text" name="l" onchange="return lname()"></td>
					</tr>
					<tr>
						<td>Email</td>
						<td><input type="text" name="eid" onchange="return email()"></td>
					</tr>
					<tr>
						<td>Password</td>
						<td><input type="password" name="pwd" onchange="return pass()"></td>
					</tr>
					<tr>
						<td>Phone No.</td>
						<td><input type="text" name="phno" onchange="return phone()"></td>
					</tr>
					<tr>
						<td>Gender</td>
						<td><input type="radio" name="r1" value="male">Male &nbsp; <input type="radio" name="r1" value="female">Female</td>
					</tr>
					<tr>
  <td>Birthday</td>
  <td>
    <select name="d" id="daySelect">
      <script>
        var i;
        for (i = 1; i <= 31; i++) {
          document.write("<option>" + i + "</option>");
        }
      </script>
    </select>
    
    <select name="m" id="monthSelect">
      <script>
        var month = new Array(
          "",
          "Jan",
          "Feb",
          "Mar",
          "Apr",
          "May",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Oct",
          "Nov",
          "Dec"
        );
        for (i = 1; i <= month.length - 1; i++) {
          document.write(
            "<option value='" + i + "'>" + month[i] + "</option>"
          );
        }
      </script>
    </select>
    
    <select name="y" id="yearSelect">
      <script>
        var currentYear = new Date().getFullYear();
        for (i = 1900; i <= currentYear; i++) {
          document.write("<option>" + i + "</option>");
        }
      </script>
    </select>

    <script>
      // Set initial date values
      var initialDay = 1;
      var initialMonth = 1;
      var initialYear = 1900;
      
      // Function to set the selected date
      function setDate() {
        var daySelect = document.getElementById("daySelect");
        var monthSelect = document.getElementById("monthSelect");
        var yearSelect = document.getElementById("yearSelect");
        
        daySelect.value = initialDay;
        monthSelect.value = initialMonth;
        yearSelect.value = initialYear;
      }
      
      // Call the setDate function to set the initial date
      setDate();
    </script>
  </td>
</tr>




					<tr>
						<td>Country</td>
						<td><input type="text" name="coun"></td>
					</tr>
					<tr>
						<td>City</td>
						<td><input type="text" name="city"></td>
					</tr>
					<tr>
						<td>Township</td>
						<td><input type="text" name="tsp"></td>
					</tr>
					<tr>
						<td colspan="2" align="center">Would you like us to send you email notification of special sales?<br>
														<input type="radio" name="r2" value="yes">Yes &nbsp; <input type="radio" name="r2" value="no">No
						</td>
					</tr>
					<tr>
						<td colspan="2" align="center"><input type="submit" name="reg" value="Create account"> &nbsp;
													   <input type="reset" value="Cancel">
						</td>
					</tr>
				</table>
			</form>
        </div>
        
      </div>
      
      <div class="clr"></div>
    </div>
  </div>







  <div class="media">
    <div class="media_resize">
      <div class="col group1">
        <div class="media_head">
          <div class="media_title">
            <span style="left:20px;" style="--clr:#06d406;" data-text="About"><a href="about.php">About</a></span>
            <span style="--clr:#06d406;" data-text="Us"><a href="about.php">Us</a></span>
          </div>
        </div><br>
        <img src="images/art1.webp" width="56" height="56" alt="pix" />
        <p align="justify">Welcome to our online boots shop, where you will find a wide selection of high-quality boots
          that are perfect for any occasion. From stylish ankle boots to practical walking boots, our collection has
          been carefully curated to bring you the best in comfort, style, and durability.
          <a href="about.php"> Read More...</a>
        </p>
      </div>
      <div class="col group2">
      <div class="media_head">
          <div class="media_title">
            <span style="left:20px;" style="--clr:#06d406;" data-text="Follow"><a href="absent.php">Follow</a></span>
            <span style="--clr:#06d406;" data-text="Us"><a href="fbsent.php">Us</a></span>
          </div>
        </div><br>
        <a href="#"><img src="images/facebook.png" width="40" height="40" alt="ad" class="ad" /></a>
        <a href="#"><img src="images/twitter.png" width="40" height="40" alt="ad" class="ad" /></a>
        <a href="#"><img src="images/telegram.png" width="40" height="40" alt="ad" class="ad" /></a>
        <a href="#"><img src="images/insta.png" width="40" height="40" alt="ad" class="ad" /></a>
      </div>
      <div class="col group3">
      <div class="media_head">
          <div class="media_title">
            <span style="left:20px;" style="--clr:#06d406;" data-text="Contact"><a href="contact.php">Contact</a></span>
            <span style="--clr:#06d406;" data-text="Us"><a href="contact.php">Us</a></span>
          </div>
        </div><br>
        <p>Welcome to our online store where you can find everything you need at unbeatable prices!
          Click here to <a href="contact.php">Our contact details</a><br>

        </p>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  
</div>
</body>
</html>
