-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 02, 2016 at 04:52 AM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bootshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE IF NOT EXISTS `brands` (
  `b_id` int(100) NOT NULL AUTO_INCREMENT,
  `b_title` text NOT NULL,
  PRIMARY KEY (`b_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`b_id`, `b_title`) VALUES
(1, 'NIKE AIR ZOOM TRRA'),
(2, 'Timeberland'),
(3, 'Dr. Martens'),
(4, 'Grenson'),
(5, 'Wolverine'),
(6, 'Ariat');

-- --------------------------------------------------------

--
-- Table structure for table `buy`
--

CREATE TABLE IF NOT EXISTS `buy` (
  `brand` varchar(20) NOT NULL,
  `size` varchar(30) NOT NULL,
  `or_cost` varchar(20) NOT NULL,
  `price` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `delivery` varchar(20) NOT NULL,
  `address` varchar(200) NOT NULL,
  `Order_no` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buy`
--

INSERT INTO `buy` (`brand`, `size`,`or_cost`, `price`, `phone`, `delivery`, `address`, `Order_no`) VALUES
('NIKE AIR ZOOM TRRA', '43-42', '$620', '$590', '123456789', '5 days', '36St.', 'no88'),
('Timeberland', '44-43', '$630', '$600', '111111111', '3 days', '36St.', 'no21'),
('Dr. Martens', '45-44', '$650', '$620', '111111111', '5 days', '35St.', 'no30');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `email` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `feedback` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`email`, `phone`, `feedback`) VALUES
('linguamarina2023@gmail.com', '09428493384', 'I recently purchased a pair of boots from this online boot shop and I could not be happier with my experience.'),
('solovirtuoso2023@gmail.com', '09943847851', 'The website was easy to navigate and had a wide variety of boots to choose from.'),
('Lovein2023@gmail.com', '099423477462', 'I appreciated the detailed product descriptions and customer reviews, which helped me choose the perfect pair for me.'),
('ibuprofen2023@gmail.com', '0925645968', 'Shipping was fast and the boots arrived in perfect condition.'),
('gobbledegook2023@gmail.com', '0939421502', 'The quality of the boots exceeded my expectations, they are comfortable, durable and stylish.'),
('bibliolater2023@gmail.com', '09040536206', 'Shipping was fast and the boots arrived in perfect condition.');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `p_id` int(100) NOT NULL AUTO_INCREMENT,
  `p_brand` text NOT NULL,
  `p_size` varchar(100) NOT NULL,
  `p_or_cost` varchar(100) NOT NULL,
  `p_price` varchar(100) NOT NULL,
  `p_image` varchar(100) NOT NULL,
  `p_desc` text NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23;
--
-- Dumping data for table `product`
--


INSERT INTO `product` (`p_id`, `p_brand`, `p_size`, `p_or_cost`, `p_price`, `p_image`, `p_desc`) VALUES
(1, 'NIKE AIR ZOOM TRRA', '43-42', '$620', '$590', 'img3.png', 'The NIKE AIR ZOOM TRRA Boot is a durable, all-terrain boot made from Pebax. Designed to withstand tough conditions, it offers functionality and style. Perfect for outdoor activities, it keeps your feet comfortable and protected during hiking, camping, or everyday errands.'),
(2, 'NIKE AIR ZOOM TRRA', '42-41', '$610', '$580', 'img4.png', 'The NIKE AIR ZOOM TRRA Boot is a durable, all-terrain boot made from Pebax. Designed to withstand tough conditions, it offers functionality and style. Perfect for outdoor activities, it keeps your feet comfortable and protected during hiking, camping, or everyday errands.'),
(3, 'Timeberland', '44-43', '$630', '$600', 'Timeberland2.png', 'The Timeberland Expression Boot merges classic design with contemporary flair, catering to those who embrace their individuality. With distinctive details and fashion-forward aesthetics, these boots empower you to express your style confidently. Combining comfort, durability, and style, they elevate any occasion, reflecting your unique self.'),
(4, 'Timeberland', '44.5-43.5', '$635', '$605', 'Timeberland1.png', 'The Timeberland Expression Boot merges classic design with contemporary flair, catering to those who embrace their individuality. With distinctive details and fashion-forward aesthetics, these boots empower you to express your style confidently. Combining comfort, durability, and style, they elevate any occasion, reflecting your unique self.'),
(5, 'Dr. Martens', '45-44', '$650', '$620', 'Dr_Martens1.png', 'The Dr. Martens 1 Boot: an enduring symbol of rebellion and durability. Crafted with precision and timeless appeal, it features a distinctive silhouette, sturdy leather, yellow stitching, and an air-cushioned sole. Experience comfort and style that lasts, making it a must-have for self-expression and undeniable craftsmanship.'),
(6, 'Dr. Martens', '43.5-42.5', '$635', '$605', 'Dr_Martens2.png', 'The Dr. Martens 1 Boot: an enduring symbol of rebellion and durability. Crafted with precision and timeless appeal, it features a distinctive silhouette, sturdy leather, yellow stitching, and an air-cushioned sole. Experience comfort and style that lasts, making it a must-have for self-expression and undeniable craftsmanship.'),
(7, 'Grenson', '40-39','$600', '$570', 'grenson1.png', 'Experience Grenson Boot: Crafted by skilled artisans, these boots embody exquisite craftsmanship and refined style. The premium leather upper, Goodyear welt construction, and timeless design ensure durability and effortless sophistication. Step into elegance with Grenson - the epitome of British shoemaking excellence.'),
(8, 'Grenson', '43.5-42.5', '$635', '$605', 'grenson2.png', 'Experience Grenson Boot: Crafted by skilled artisans, these boots embody exquisite craftsmanship and refined style. The premium leather upper, Goodyear welt construction, and timeless design ensure durability and effortless sophistication. Step into elegance with Grenson - the epitome of British shoemaking excellence.'),
(9, 'Wolverine', '41-40', '$600', '$570', 'wolverine1.png', 'The Wolverine Boot: a timeless classic of durability and performance. Meticulously crafted with premium leather, Goodyear welt construction, and a slip-resistant outsole. These boots offer comfort, resilience, and style for rugged environments, work, or outdoor adventures. Trust Wolverine for quality, reliability, and enduring appeal.'),
(10, 'Wolverine', '43-42', '$620', '$590', 'wolverine2.png', 'The Wolverine Boot: a timeless classic of durability and performance. Meticulously crafted with premium leather, Goodyear welt construction, and a slip-resistant outsole. These boots offer comfort, resilience, and style for rugged environments, work, or outdoor adventures. Trust Wolverine for quality, reliability, and enduring appeal.'),
(11, 'Ariat', '44-43', '$680', '$650', 'ariat1.png', 'The Ariat Boot: a perfect blend of style and functionality. Crafted with premium materials, these boots offer durability and comfort. With their sleek design and advanced technology, they provide excellent support and traction for any outdoor activity. Elevate your footwear collection with Ariat exceptional quality and performance.'),
(12, 'Ariat', '43.5-42.5', '$675', '$645', 'ariat2.png', 'The Ariat Boot: a perfect blend of style and functionality. Crafted with premium materials, these boots offer durability and comfort. With their sleek design and advanced technology, they provide excellent support and traction for any outdoor activity. Elevate your footwear collection with Ariat exceptional quality and performance.');


-- --------------------------------------------------------

--
-- Table structure for table `sign_up`
--

CREATE TABLE IF NOT EXISTS `sign_up` (
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `gender` text NOT NULL,
  `birthday` varchar(20) NOT NULL,
  `country` text NOT NULL,
  `city` text NOT NULL,
  `township` text NOT NULL,
  `email_noti` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sign_up`
--

INSERT INTO `sign_up` (`first_name`, `last_name`, `email`, `password`, `phone_no`, `gender`, `birthday`, `country`, `city`, `township`, `email_noti`) VALUES
('Ibupro', 'Fen', 'ibuprofen2023@gmail.com', '121312', '09938283283', 'female', '1/1/1996', 'USA', 'Columbus', 'Franklin', 'yes'),
('Lingua', 'Marina', 'linguamarina2023@gmail.com', '212321', '987654321', 'female', '1/10/1980', 'Bloomfield Hills', 'Yangon', 'Bloomfield', 'no'),
('Love', 'In', 'lovein2023@gmail.com', '232123', '09959594823', 'male', '20/12/1997', 'Myanmar', 'Pennsylvania', 'Cranberry', 'no'),
('Biblio', 'Later', 'bibliolater2023@gmail.com', '213231', '099949225', 'male', '17/2/1987', 'Myanmar', 'Indianapolis', 'Wayne', 'yes'),
('Gobblede', 'Gook', 'gobbledegook2023@gmail.com', '123212', '0998248282', 'male', '1/1/1990', 'Myanmar', 'Greensburg', 'Manheim', 'no'),
('Solo', 'Virtuoso', 'solovirtuoso2023@gmail.com', '212321', '0948374765', 'male', '1/1/1990', 'USA', 'Manheim', 'Bloomfield', 'no');
-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `name` text NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `password`) VALUES
('Create Admin', 'Superuser Admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `email` varchar(50) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table `contact`
--

INSERT INTO `contact` (`email`, `phone`, `message`) VALUES
('johndoe2023@gmail.com', '095551234', 'I have a question about your products.'),
('janesmith2023@gmail.com', '095555678', 'I love your boots! They are so comfortable and stylish.'),
('mikejohnson2023@gmail.com', '095559012', 'I need assistance with placing an order.');
