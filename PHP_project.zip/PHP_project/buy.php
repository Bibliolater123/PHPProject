<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Online Bootshop Shop</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/menu_bar.css">
<link rel="stylesheet" href="css/logo.css">
<link rel="stylesheet" href="css/detail.css">
<link rel="stylesheet" href="css/table.css">
<!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/arial.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>
<!-- CuFon ends -->

<?php
session_start();
	error_reporting(1);
	
	include("dbconnect.php");
	
	$product_brand = $_REQUEST['buy_pro'];
	
	if(isset($_REQUEST['buy']))
	{
		$b = $_REQUEST['b'];
		$s = $_REQUEST['s'];
    $p_or = $_REQUEST['p_or'];
		$p = $_REQUEST['p'];
		$phno = $_REQUEST['phno'];
		$delivery = $_REQUEST['r'];
		$add = $_REQUEST['add'];
		$order_no = no.rand(1,100);
		if(mysql_query("INSERT INTO buy VALUES('$b', '$s', '$p_or', '$p', '$phno', '$delivery', '$add', '$order_no')"))
		{
			echo "<script>location.href='buysuccess.php?order_no=$order_no'</script>";
		}
	}
?>

</head>
<body>
<div class="main">

<div class="header">
    <div class="header_resize">
    <div class="menu-bar">
          <div class="menu_position">
            <ul>
              <li style="--clr:#030000"><a href="index.php" data-text="&nbsp;online shop">
              &nbsp;online shop&nbsp;</a> <!-- logo --></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <li style="--clr:#00ade1"><a href="index.php" data-text="&nbsp;Home">&nbsp;Home&nbsp;</a></li>
              <li style="--clr:#f11313"><a href="about.php" data-text="&nbsp;About Us">&nbsp;About Us&nbsp;</a></li>
              <li style="--clr:#ffdd1c"><a href="product.php" data-text="&nbsp;Products">&nbsp;Products&nbsp;</a></li>
              <li style="--clr:#dc00d4"><a href="contact.php" data-text="&nbsp;Contact Us">&nbsp;Contact Us&nbsp;</a></li>
              <li style="--clr:#06d406"><a href="signup.php" data-text="&nbsp;Register">&nbsp;Register&nbsp;</a></li>
              <li style="--clr:#5613f1"><a href="login.php" data-text="&nbsp;Log in">&nbsp;Log In&nbsp;</a></li>
              <li style="--clr:#13d0f1"><a href="index.php" data-text="&nbsp;Log Out">&nbsp;Log Out&nbsp;</a></li>
            </ul>
          </div>
        </div> <!-- menu-bar -->
	  <div class="clr"></div>
    <div class="mainBox">
      <div class="smallBox"></div>
      <h2><a href="index.php"><span style="--clr:#00ade1">L</span><span style="--clr:#f11313">i</span><span style="--clr:#ffdd1c">t</span><span style="--clr:#dc00d4">t</span><span style="--clr:#06d406">l</span><span style="--clr:#5613f1">e</span></a></h2>
    </div> 
  <a href="index.php"><h3>online shop</h3></a> <!-- logo -->
      <div class="clr"></div>
      <div class="clr"></div>
      
     
    </div>
  </div>

  
<br><br><br><br><br><br>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
		
		<h2>Buy a product</h2>
		 
		  </p>
		  <p>If you want to order what you've choosen, please fill the following order form.</p>
		  <p>Our standard delivery is 5 days and delivery fee is $3. But if you preferred a rush, you can choose 3 days or next day. Delivery fee is $7.</p>
		  <p>Thank you. Enjoy your shopping!!</p>
        <form method="post">
			<?php
				
				$sel=mysql_query("select * from product where p_id='$product_brand'");
				$mat=mysql_fetch_array($sel);
			?>
			<table border="0" cellpadding="10px">
				<tr>
					<td>brand</td>
					<td><input type="text" name="b" value="<?php echo $mat['p_brand']; ?>"></td>
				</tr>
				<tr>
					<td>Size</td>
					<td><input type="text" name="s" value="<?php echo $mat['p_size']; ?>"></td>
				</tr>

				<tr>
					<td>Original Price</td>
					<td><input type="text" name="p_or" value="<?php echo $mat['p_or_cost']; ?>"></td>
				</tr>
				<tr>
					<td>Now Price</td>
					<td><input type="text" name="p" value="<?php echo $mat['p_price']; ?>"></td>
				</tr>
				<tr>
					<td>Phone Number</td>
					<td><input type="text" name="phno" required></td>
				</tr>
				<tr>
					<td>Preferred Delivery</td>
					<td><input type="radio" name="r" value="5 days" required>5 days
					    <input type="radio" name="r" value="3 days" required>3 days
						<input type="radio" name="r" value="next day" required>next day
					</td>
				</tr>
				<tr>
					<td>Address</td>
					<td><textarea name="add" required></textarea></td>
				</tr>
				<tr>
					<td colspan="2" align="center"><input type="submit" name="buy" value="Buy"> &nbsp;
                          <a href="index.php" class="cancel">Cancel</a>

					</td>
				</tr>

        
        
		
			</table>
		</form>
      </div>
      
      <div class="clr"></div>
    </div>
  </div>

  <div class="media">
    <div class="media_resize">
      <div class="col group1">
        <div class="media_head">
          <div class="media_title">
            <span style="left:20px;" style="--clr:#5613f1;" data-text="About"><a href="about.php">About</a></span>
            <span style="--clr:#5613f1;" data-text="Us"><a href="about.php">Us</a></span>
          </div>
        </div><br>
        <img src="images/art1.webp" width="56" height="56" alt="pix" />
        <p align="justify">Welcome to our online boots shop, where you will find a wide selection of high-quality boots
          that are perfect for any occasion. From stylish ankle boots to practical walking boots, our collection has
          been carefully curated to bring you the best in comfort, style, and durability.
          <a href="about.php"> Read More...</a>
        </p>
      </div>
      <div class="col group2">
      <div class="media_head">
          <div class="media_title">
            <span style="left:20px;" style="--clr:#5613f1;" data-text="Follow"><a href="fbsent.php">Follow</a></span>
            <span style="--clr:#5613f1;" data-text="Us"><a href="fbsent.php">Us</a></span>
          </div>
        </div><br>
        <a href="#"><img src="images/facebook.png" width="40" height="40" alt="ad" class="ad" /></a>
        <a href="#"><img src="images/twitter.png" width="40" height="40" alt="ad" class="ad" /></a>
        <a href="#"><img src="images/telegram.png" width="40" height="40" alt="ad" class="ad" /></a>
        <a href="#"><img src="images/insta.png" width="40" height="40" alt="ad" class="ad" /></a>
      </div>
      <div class="col group3">
      <div class="media_head">
          <div class="media_title">
            <span style="left:20px;" style="--clr:#5613f1;" data-text="Contact"><a href="contact.php">Contact</a></span>
            <span style="--clr:#5613f1;" data-text="Us"><a href="contact.php">Us</a></span>
          </div>
        </div><br>
        <p>Welcome to our online store where you can find everything you need at unbeatable prices!
          Click here to <a href="contact.php">Our contact details</a><br>

        </p>
      </div>
      <div class="clr"></div>
    </div>
  </div>
 


</div>
</body>
</html>
