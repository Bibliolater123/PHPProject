<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/menu_bar.css">
<link rel="stylesheet" href="css/logo.css">
<link rel="stylesheet" href="css/login.css">
<!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/arial.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>
<!-- CuFon ends -->



<?php
session_start();
  error_reporting(1);
  include("dbconnect.php");
  
  $id = $_REQUEST['buy_pro'];
  if(isset($_REQUEST['login']))
  {
    $email = $_REQUEST['email'];
    $pass = $_REQUEST['pass'];
    // $query = mysqli_query($conn, "SELECT FROM sign_up WHERE email='$email'");
    // $arr = mysqli_fetch_array($query);
    $query = mysql_query("SELECT email,password FROM sign_up WHERE email='$email'");
		$arr = mysql_fetch_array($query);
    if(($arr['email']==$email) && ($arr['password']==$pass))
    {
      echo "<script>location.href='buy.php?buy_pro=$id'</script>";
    }
    else
    {
      $er="UserID or Password do not match.Try again.";
    }
  }
?>
<style>

	.mainbar p{font-size:16px;}

</style>
</head>
<body>
<div class="main">

  <div class="header">
    <div class="header_resize">
    <div class="menu-bar">
          <div class="menu_position">
            <ul>
              <li style="--clr:#030000"><a href="index.php" data-text="&nbsp;online shop">
              &nbsp;online shop&nbsp;</a> <!-- logo --></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <li style="--clr:#00ade1"><a href="index.php" data-text="&nbsp;Home">&nbsp;Home&nbsp;</a></li>
              <li style="--clr:#f11313"><a href="about.php" data-text="&nbsp;About Us">&nbsp;About Us&nbsp;</a></li>
              <li style="--clr:#ffdd1c"><a href="product.php" data-text="&nbsp;Products">&nbsp;Products&nbsp;</a></li>
              <li style="--clr:#dc00d4"><a href="contact.php" data-text="&nbsp;Contact Us">&nbsp;Contact Us&nbsp;</a></li>
              <li style="--clr:#06d406"><a href="signup.php" data-text="&nbsp;Register">&nbsp;Register&nbsp;</a></li>
              <li style="--clr:#5613f1"><a class="active" style="font-size:1.2em;" href="login.php" data-text="&nbsp;Log in">&nbsp;Log In&nbsp;</a></li>
              <li style="--clr:#13d0f1"><a href="index.php" data-text="&nbsp;Log Out">&nbsp;Log Out&nbsp;</a></li>
            </ul>
          </div>
        </div> <!-- menu-bar -->
	  <div class="clr"></div>
    <div class="mainBox">
      <div class="smallBox"></div>
      <h2><a href="index.php"><span style="--clr:#00ade1">L</span><span style="--clr:#f11313">i</span><span style="--clr:#ffdd1c">t</span><span style="--clr:#dc00d4">t</span><span style="--clr:#06d406">l</span><span style="--clr:#5613f1">e</span></a></h2>
    </div> 
  <a href="index.php"><h3>online shop</h3></a>
      <div class="clr"></div>
      <div class="clr"></div>
     
    </div>
  </div>

  <div class="content"><br><br><br><br><br>
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
         
		  <p>&nbsp;&nbsp;&nbsp;&nbsp;If you want to buy a product you have chosen, please log in with your member account.</p>
			<form method="post">
				<table border="0" cellpadding="15px" style="font-size:16px; font-weight:bold;" align="center">
					<tr><td colspan="2"><?php echo "<font color='red'>$er</font>";?></td></tr>
					<tr>
						<td>&nbsp;&nbsp;&nbsp;&nbsp;Email</td>
						<td><input type="text" name="email"></td>
					</tr>
					<tr>
						<td>&nbsp;&nbsp;&nbsp;&nbsp;Password</td>
						<td><input type="password" name="pass"></td>
					</tr>
					
					<tr>
						<td colspan="2" align="center">
              <input type="submit" name="login" value="Log In"> <br><br>
							<a class="create_account" href="signup.php">Create account</a>
						</td>
					</tr>
				</table>
			</form>
        </div>
        
      </div>
      
      <div class="clr"></div>
    </div>
  </div>

  <div class="media">
    <div class="media_resize">
      <div class="col group1">
        <div class="media_head">
          <div class="media_title">
            <span style="left:20px;" style="--clr:#5613f1;" data-text="About"><a href="about.php">About</a></span>
            <span style="--clr:#5613f1;" data-text="Us"><a href="about.php">Us</a></span>
          </div>
        </div><br>
        <img src="images/art1.webp" width="56" height="56" alt="pix" />
        <p align="justify">Welcome to our online boots shop, where you will find a wide selection of high-quality boots
          that are perfect for any occasion. From stylish ankle boots to practical walking boots, our collection has
          been carefully curated to bring you the best in comfort, style, and durability.
          <a href="about.php"> Read More...</a>
        </p>
      </div>
      <div class="col group2">
      <div class="media_head">
          <div class="media_title">
            <span style="left:20px;" style="--clr:#5613f1;" data-text="Follow"><a href="fbsent.php">Follow</a></span>
            <span style="--clr:#5613f1;" data-text="Us"><a href="fbsent.php">Us</a></span>
          </div>
        </div><br>
        <a href="#"><img src="images/facebook.png" width="40" height="40" alt="ad" class="ad" /></a>
        <a href="#"><img src="images/twitter.png" width="40" height="40" alt="ad" class="ad" /></a>
        <a href="#"><img src="images/telegram.png" width="40" height="40" alt="ad" class="ad" /></a>
        <a href="#"><img src="images/insta.png" width="40" height="40" alt="ad" class="ad" /></a>
      </div>
      <div class="col group3">
      <div class="media_head">
          <div class="media_title">
            <span style="left:20px;" style="--clr:#5613f1;" data-text="Contact"><a href="contact.php">Contact</a></span>
            <span style="--clr:#5613f1;" data-text="Us"><a href="contact.php">Us</a></span>
          </div>
        </div><br>
        <p>Welcome to our online store where you can find everything you need at unbeatable prices!
          Click here to <a href="contact.php">Our contact details</a><br>

        </p>
      </div>
      <div class="clr"></div>
    </div>
  </div>

</div> <!-- container !-->

<script type="text/javascript">
    const buttons = document.querySelectorAll('.create_account');
    buttons.forEach(btn => {
      btn.addEventListener('click', function (e) {
        e.preventDefault(); // Prevent the default navigation behavior

        let x = e.clientX - e.target.offsetLeft;
        let y = e.clientY - e.target.offsetTop;

        let container = document.createElement('div');
        container.classList.add('click_bubble');
        container.style.left = x + 'px';
        container.style.top = y + 'px';

        this.appendChild(container);

        setTimeout(() => {
          container.remove();
          if (this.tagName === 'INPUT') {
            // If the clicked element is an input, programmatically submit the form
            this.closest('form').submit();
          } else {
            // Otherwise, navigate to the target URL after the animation
            window.location.href = this.href;
          }
        }, 1000); // Wait for 1 seconds (1000 milliseconds)
      });
    });
  </script>
</body>
</html>
