<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Success</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/menu_bar.css">
<link rel="stylesheet" href="css/home.css">
<!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/arial.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>
<!-- CuFon ends -->
<style>

	.article p{font-size:14px; font-weight:bold;}

</style>
<?php
	error_reporting(1);
	
	include("dbconnect.php");
	
	if($_REQUEST['log']=='out')
	{
		session_destroy();
		header("location:index.php");
	}
?>

</head>
<body>
<div class="main">

<div class="header">
      <div class="header_resize">
      <div class="menu-bar">
          <div class="menu_position">
            <ul>
              <li style="--clr:#030000"><a href="index.php" data-text="&nbsp;online shop">
              &nbsp;online shop&nbsp;
    </a> <!-- logo --></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <li style="--clr:#00ade1"><a data-text="&nbsp;Home">&nbsp;Home&nbsp;</a></li>
              <li style="--clr:#f11313"><a href="about.php" data-text="&nbsp;About Us">&nbsp;About Us&nbsp;</a></li>
              <li style="--clr:#ffdd1c"><a href="product.php" data-text="&nbsp;Products">&nbsp;Products&nbsp;</a></li>
              <li style="--clr:#dc00d4"><a class="active" style="font-size:1.2em;" href="contact.php" data-text="&nbsp;Contact Us">&nbsp;Contact Us&nbsp;</a></li>
              <li style="--clr:#06d406"><a href="signup.php" data-text="&nbsp;Register">&nbsp;Register&nbsp;</a></li>
              <li style="--clr:#5613f1"><a href="index.php" href="login.php" data-text="&nbsp;Log in">&nbsp;Log In&nbsp;</a></li>
              <li style="--clr:#13d0f1"><a href="index.php" data-text="&nbsp;Log Out">&nbsp;Log Out&nbsp;</a></li>
            </ul>
          </div>
        </div> <!-- menu-bar -->
        </div> <!-- header_resize -->
    </div> <!-- header -->

  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2>Welcome!! <?php echo "<font color=maroon>".@$_REQUEST['first']."&nbsp;".@$_REQUEST['last']."</font>"; ?> </h2>
			<br>
			<p>You have created your account successfully!!!</p>
			<p>Your UserID is: <?php echo "<font color=maroon size=4><i>".@$_REQUEST['wel']."</i></font>";?></p>
			<p>Enjoy your shopping!</p>
			<p>Thank you.</p>
			<p><a href="?log=out">Go back</a></p>
        </div>
        
      </div>
      
      <div class="clr"></div>
    </div>
  </div>

  <div class="media">
    <div class="media_resize">
      <div class="col group1">
        <div class="hdbody">
          <div class="abhead">
            <span style="left:20px;" style="--clr:#00ade1;" data-text="About"><a href="about.php">About</a></span>
            <span style="--clr:#00ade1;" data-text="Us"><a href="about.php">Us</a></span>
          </div>
        </div><br>
        <img src="images/art1.webp" width="56" height="56" alt="pix" />
        <p align="justify">Welcome to our online boots shop, where you will find a wide selection of high-quality boots
          that are perfect for any occasion. From stylish ankle boots to practical walking boots, our collection has
          been carefully curated to bring you the best in comfort, style, and durability.
          <a href="about.php"> Read More...</a>
        </p>
      </div>
      <div class="col group2">
        &nbsp;<h2><span>Follows Us:</span></h2>
        <a href="#"><img src="images/facebook.png" width="40" height="40" alt="ad" class="ad" /></a>
        <a href="#"><img src="images/twitter.png" width="40" height="40" alt="ad" class="ad" /></a>
        <a href="#"><img src="images/telegram.png" width="40" height="40" alt="ad" class="ad" /></a>
        <a href="#"><img src="images/insta.png" width="40" height="40" alt="ad" class="ad" /></a>
      </div>
      <div class="col group3">
        &nbsp;&nbsp;<h2><a href="contact.php">Contact</a></h2>
        <p>Welcome to our online store where you can find everything you need at unbeatable prices!
          Click here to <a href="contact.php">Our contact details</a><br>

        </p>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">

      <ul class="fmenu">
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About Us</a></li>
        <li><a href="signup.php">Sign Up</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
      <div class="clr"></div>
    </div>
  </div>

</div>
</body>
</html>
