<?php
// Add this PHP code at the top of your PHP file (e.g., home.php)

// Check if the user is logged in and redirect to the login page if not
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Database connection
include("dbconnect.php");

// Check if the form is submitted
if (isset($_POST['add_favorite'])) {
    $product_id = $_POST['product_id'];
    $user_id = $_SESSION['user_id'];

    // Check if the product is already added as a favorite
    $check_favorite_query = "SELECT * FROM favorites WHERE user_id = ? AND product_id = ?";
    $check_favorite_stmt = mysqli_prepare($con, $check_favorite_query);
    mysqli_stmt_bind_param($check_favorite_stmt, "ii", $user_id, $product_id);
    mysqli_stmt_execute($check_favorite_stmt);
    $check_favorite_result = mysqli_stmt_get_result($check_favorite_stmt);

    if (mysqli_num_rows($check_favorite_result) > 0) {
        // Product is already a favorite
        echo "<p>Product is already a favorite!</p>";
    } else {
        // Add the product as a favorite
        $add_favorite_query = "INSERT INTO favorites (user_id, product_id) VALUES (?, ?)";
        $add_favorite_stmt = mysqli_prepare($con, $add_favorite_query);
        mysqli_stmt_bind_param($add_favorite_stmt, "ii", $user_id, $product_id);

        if (mysqli_stmt_execute($add_favorite_stmt)) {
            echo "<p>Product added to favorites!</p>";
        } else {
            echo "<p>Failed to add product to favorites!</p>";
        }
    }
}
?>

<!-- Add this HTML code in place of the existing form code in the given admin login page -->

<form method="post" action="login.php">
    <table border="0" cellpadding="10px">
        <tr>
            <td colspan="2"><?php echo isset($error) ? "<font color='red'>$error</font>" : ""; ?></td>
        </tr>
        <tr>
            <td>User Name</td>
            <td><input type="text" name="uname" required></td>
        </tr>
        <tr>
            <td>Password</td>
            <td><input type="password" name="pass" required></td>
        </tr>
        <tr>
            <td colspan="2"><input class="submit" type="submit" name="login" value="Log In"></td>
        </tr>
    </table>
</form>

<!-- Add this HTML code after the closing </form> tag in the given admin login page -->
<!-- This code displays the list of products with an "Add Favorite" button -->

<h2>Product List</h2>
<table>
    <tr>
        <th>Product ID</th>
        <th>Product Name</th>
        <th>Action</th>
    </tr>
    <?php
    // Retrieve the list of products from the database
    $products_query = "SELECT * FROM products";
    $products_result = mysqli_query($con, $products_query);

    while ($row = mysqli_fetch_assoc($products_result)) {
        $product_id = $row['product_id'];
        $product_name = $row['product_name'];
        ?>
        <tr>
            <td><?php echo $product_id; ?></td>
            <td><?php echo $product_name; ?></td>
            <td>
                <form method="post" action="home.php" id="form_<?php echo $product_id; ?>">
                    <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                    <input type="submit" name="add_favorite" value="Add Favorite">
                </form>
            </td>
        </tr>
        <?php
    }
    ?>
</table>
