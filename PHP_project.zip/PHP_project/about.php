<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>About Us</title>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <link href="css/style.css" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="css/menu_bar.css">
  <link rel="stylesheet" href="css/logo.css">
  <link rel="stylesheet" href="css/style_main.css">
  <link rel="stylesheet" href="css/bag.css">
  <!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
  <script type="text/javascript" src="js/cufon-yui.js"></script>
  <script type="text/javascript" src="js/arial.js"></script>
  <script type="text/javascript" src="js/cuf_run.js"></script>
  <!-- CuFon ends -->

  <?php

  include("admin/function.php");

  ?>

</head>

<body>
  <div class="main">

    <div class="header">
      <div class="header_resize">
      <div class="menu-bar">
          <div class="menu_position">
            <ul>
              <li style="--clr:#030000"><a href="index.php" data-text="&nbsp;online shop">
              &nbsp;online shop&nbsp;
    </a> <!-- logo --></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <li style="--clr:#00ade1"><a href="index.php" data-text="&nbsp;Home">&nbsp;Home&nbsp;</a></li>
              <li style="--clr:#f11313"><a class="active" style="font-size:1.2em;" href="about.php" data-text="&nbsp;About Us">&nbsp;About Us&nbsp;</a></li>
              <li style="--clr:#ffdd1c"><a href="product.php" data-text="&nbsp;Products">&nbsp;Products&nbsp;</a></li>
              <li style="--clr:#dc00d4"><a href="contact.php" data-text="&nbsp;Contact Us">&nbsp;Contact Us&nbsp;</a></li>
              <li style="--clr:#06d406"><a href="signup.php" data-text="&nbsp;Register">&nbsp;Register&nbsp;</a></li>
              <li style="--clr:#5613f1"><a href="login.php" data-text="&nbsp;Log in">&nbsp;Log In&nbsp;</a></li>
              <li style="--clr:#13d0f1"><a href="index.php" data-text="&nbsp;Log Out">&nbsp;Log Out&nbsp;</a></li>
            </ul>
          </div>
        </div> <!-- menu-bar -->

        <div class="clr"></div>
        <div class="mainBox">
          <div class="smallBox"></div>
          <h2><a href="index.php"><span style="--clr:#00ade1">L</span><span style="--clr:#f11313">i</span><span style="--clr:#ffdd1c">t</span><span style="--clr:#dc00d4">t</span><span style="--clr:#06d406">l</span><span style="--clr:#5613f1">e</span></a></h2>
        </div>
        <a href="index.php">
          <h3>online shop</h3>
        </a>
        <div class="clr"></div>

        <?php
        error_reporting(1);
        include("including/index1.html");
        ?>
        <div class="img_resize">
          <img src="images/walking.png" alt="image" style="float:left;" />
          <div class="paper-dangling">
            <img src="images/shopping_bags.png" alt="" height="120px" width="120px">
          </div>
          <?php

          error_reporting(1);
          include("anishoe.html");

          ?>
        </div>
      </div>
    </div>
    <div class="clr"></div>

    <div class="col group1">
      <div class="media_head" style="--m_h_c:#ec9595">
          <div class="media_title">
            <span style="left:20px;" style="--clr:#f11313;" data-text="About"><a>About</a></span>
            <span style="--clr:#f11313;" data-text="Us"><a>Us</a></span>
          </div>
        </div><br>
            <p class="paragraph">
              <span style="--delay: 1s;"><b class="welcome">Welcome</b> to our online boots shop, where you will find a wide selection of high-quality boots
                that are perfect for any occasion.</span>
              <span style="--delay: 1s;">Our premium quality boots are designed to meet the needs of modern-day adventurers,
                made with durable materials, they're perfect for hiking, trekking, or exploring the great outdoors.</span>
              <span style="--delay: 1s;">With their slip-resistant outsole and waterproof lining, these boots provide excellent grip
                and protection against harsh weather conditions. </span>
              <span style="--delay: 1.1s;">They're also comfortable to wear, with a padded collar and insole, making them suitable for everyday wear.
                Get ready to take on any terrain in style, with our amazing boots.</span>
              <span style="--delay: 1.15s;">From stylish ankle boots to practical walking boots, our collection has
                been carefully curated to bring you the best in comfort, style, and durability.</span>
              <span style="--delay: 1.2s;">Whether you're looking for a pair of boots to complete your everyday look or need something more
                rugged for outdoor adventures, we've got you covered. We offer boots in a variety of colors, materials,
                and sizes to suit any taste and need.</span>
              <span style="--delay: 1.3s;">You can shop with confidence knowing that all of our boots are made from the finest materials, and we offer
                free returns on all purchases. So start shopping today and step up your footwear game with our collection of boots.</span>
              <span style="--delay: 1.4s;">You can order your favorite smart boot by filling order form if you have an account. You don't have to worry about to create your
                member account. If you don't have an account, you can easily create your account <a href="signup.php">here</a>.</span>
              <span style="--delay: 1.5s;">If you need any assistance you can call our call center or send an email. For any suggestion, you can also give us a feedback.</span>
              <span style="--delay: 1.6s;">We are ready to help you back. We have a page on facebook, so you can also give us any comment or suggestion or advice
                in comment box of facebook.</span>
            </p>





        <div class="clr"></div>
    </div>

    <div class="media">
      <div class="media_resize">

        <div class="col group2">
        <div class="media_head" style="--m_h_c:#ec9595">
          <div class="media_title">
            <span style="left:20px;" style="--clr:#f11313;" data-text="Follow"><a href="fbsent.php">Follow</a></span>
            <span style="--clr:#f11313;" data-text="Us"><a href="fbsent.php">Us</a></span>
          </div>
        </div><br>
          <a href="#"><img src="images/facebook.png" width="40" height="40" alt="ad" class="ad" style="--i_h:#f11313;"/></a>
          <a href="#"><img src="images/twitter.png" width="40" height="40" alt="ad" class="ad" style="--i_h:#f11313;" /></a>
          <a href="#"><img src="images/telegram.png" width="40" height="40" alt="ad" class="ad" style="--i_h:#f11313;" /></a>
          <a href="#"><img src="images/insta.png" width="40" height="40" alt="ad" class="ad" style="--i_h:#f11313;" /></a>
        </div>
        <div class="col group3"><br>
          <div class="media_head" style="--m_h_c:#ec9595">
          <div class="media_title">
            <span style="left:20px;" style="--clr:#f11313;" data-text="Contact"><a href="contact.php">Contact</a></span>
            <span style="--clr:#f11313;" data-text="Us"><a href="contact.php">Us</a></span>
          </div>
        </div><br>
          <p>Welcome to our online store where you can find everything you need at unbeatable prices!
            Click here to <a href="contact.php">Our contact details</a><br>
          </p>
        </div>

        <div class="clr"></div>
      </div>
    </div>

  </div> <!-- container !-->
</body>

</html>