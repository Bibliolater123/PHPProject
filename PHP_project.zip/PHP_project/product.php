<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  
<head>
<title>Online Smartphone Shop</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/menu_bar.css">
<link rel="stylesheet" href="css/logo.css">
<link rel="stylesheet" href="css/style_main.css">
<link rel="stylesheet" href="css/product.css">
<link rel="stylesheet" href="css/bag.css">
<!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/arial.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>
<!-- CuFon ends -->
<style>
  :root{
    --p_c: #ffffe3;
    --second-color: #ffffe3;
    --third-color: #ffffe3;
    }
	.mainbar div{float:left;}
</style>
<?php

error_reporting(1);
include("admin/function.php");

?>

</head>
<body>
<div class="container">

  <div class="header">
    <div class="header_resize">
    <div class="menu-bar">
          <div class="menu_position">
            <ul>
              <li style="--clr:#030000"><a href="index.php" data-text="&nbsp;online shop">
              &nbsp;online shop&nbsp;
    </a> <!-- logo --></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <li style="--clr:#00ade1"><a href="index.php"  data-text="&nbsp;Home">&nbsp;Home&nbsp;</a></li>
              <li style="--clr:#f11313"><a href="about.php" data-text="&nbsp;About Us">&nbsp;About Us&nbsp;</a></li>
              <li style="--clr:#ffdd1c"><a class="active" style="font-size:1.2em;" href="product.php" data-text="&nbsp;Products">&nbsp;Products&nbsp;</a></li>
              <li style="--clr:#dc00d4"><a href="contact.php" data-text="&nbsp;Contact Us">&nbsp;Contact Us&nbsp;</a></li>
              <li style="--clr:#06d406"><a href="signup.php" data-text="&nbsp;Register">&nbsp;Register&nbsp;</a></li>
              <li style="--clr:#5613f1"><a href="login.php" data-text="&nbsp;Log in">&nbsp;Log In&nbsp;</a></li>
              <li style="--clr:#13d0f1"><a href="index.php" data-text="&nbsp;Log Out">&nbsp;Log Out&nbsp;</a></li>
            </ul>
          </div>
        </div> <!-- menu-bar -->

 
    
    <div class="mainBox">
      <div class="smallBox"></div>
      <h2><a href="index.php"><span style="--clr:#00ade1">L</span><span style="--clr:#f11313">i</span><span style="--clr:#ffdd1c">t</span><span style="--clr:#dc00d4">t</span><span style="--clr:#06d406">l</span><span style="--clr:#5613f1">e</span></a></h2>
    </div> 
  <a href="index.php"><h3>online shop</h3></a> <!-- logo -->

  <div class="search">
    <form>
      <input type="text" name="search" placeholder="Search..">
    </form>
</div>




<?php

error_reporting(1);
include("including/index1.html");

?>
  <div class="img_resize">
    <img src="images/walking.png" alt="image" style="float:left;" />
    <div class="paper-dangling">
      <img src="images/shopping_bags.png" alt="" height="120px" width="120px">
    </div>
    <?php

error_reporting(1);
include("anishoe.html");

?>
  </div>
      <div class="clr"></div>
    </div>  <!-- header_resize -->
  </div>   <!-- header -->

  <div class='pdbg'>
  <h1 class='title-shop'>Products of our shop</h1>
	<main class='main bd-grid'>
		
		<?php getProduct(); ?>
		<?php getBrandPro(); ?>
        
      <div class="sidebar">
        <div class="gadget">
          <ul class="sb_menu">
		  
            <?php getBrands(); ?>
			
          </ul>
        </div>
      </div>
      <div class="clr"></div>
  </main>
  </div>

  <div class="media">
    <div class="media_resize">
      <div class="col group1">
        <div class="media_head" style="--m_h_c:#fdee96">
          <div class="media_title">
            <span style="left:20px;" style="--clr:#ffdd1c;" data-text="About"><a href="about.php">About</a></span>
            <span style="--clr:#ffdd1c;" data-text="Us"><a href="about.php">Us</a></span>
          </div>
        </div><br>
        <img src="images/art1.webp" width="56" height="56" alt="pix" />
        <p align="justify">Welcome to our online boots shop, where you will find a wide selection of high-quality boots
          that are perfect for any occasion. From stylish ankle boots to practical walking boots, our collection has
          been carefully curated to bring you the best in comfort, style, and durability.
          <a href="about.php" style="--m_t_p_a_c:#c2a504"> Read More...</a>
        </p>
      </div>
      <div class="col group2">
      <div class="media_head" style="--m_h_c:#fdee96">
          <div class="media_title">
            <span style="left:20px;" style="--clr:#ffdd1c;" data-text="Contact"><a href="contact.php">Contact</a></span>
            <span style="--clr:#ffdd1c;" data-text="Us"><a href="contact.php">Us</a></span>
          </div>
        </div><br>
        <a href="#"><img src="images/facebook.png" width="40" height="40" alt="ad" class="ad" /></a>
        <a href="#"><img src="images/twitter.png" width="40" height="40" alt="ad" class="ad" /></a>
        <a href="#"><img src="images/telegram.png" width="40" height="40" alt="ad" class="ad" /></a>
        <a href="#"><img src="images/insta.png" width="40" height="40" alt="ad" class="ad" /></a>
      </div>
      <div class="col group3">
      <div class="media_head" style="--m_h_c:#fdee96">
          <div class="media_title">
            <span style="left:20px;" style="--clr:#ffdd1c;" data-text="Contact"><a href="contact.php">Contact</a></span>
            <span style="--clr:#ffdd1c;" data-text="Us"><a href="contact.php">Us</a></span>
          </div>
        </div><br>
        <p>Welcome to our online store where you can find everything you need at unbeatable prices!
          Click here to <a href="contact.php" style="--m_t_p_a_c:#c2a504">Our contact details</a><br>

        </p>
      </div>
      <div class="clr"></div>
    </div>
  </div>

</div> <!-- main -->
</body>
</html>
