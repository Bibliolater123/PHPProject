<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>View Order</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="adminstyle.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/menu-bar.css">
<link rel="stylesheet" href="css/order.css">
<!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/arial.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>
<!-- CuFon ends -->



</head>
<body>
<div class="main">

    <div class="header">
      <div class="header_resize">
        <div class="menu-bar menu_resize">
          <ul>
            <li style="--clr:#00ade1"><a href="home.php" data-text="&nbsp;Home"><span><span>&nbsp;Home&nbsp;</span></span></a></li>
            <li style="--clr:#f11313"><a href="insert_product.php" data-text="&nbsp;Add Product"><span><span>&nbsp;Add Product&nbsp;</span></span></a></li>
            <li style="--clr:#ffdd1c"><a href="view_product.php" data-text="&nbsp;View Products"><span><span>&nbsp;View Products&nbsp;</span></span></a></li>
			<li style="--clr:#dc00d4"><a href="feedback.php" data-text="&nbsp;View feedback">&nbsp;View feedback&nbsp;</a></li>
            <li style="--clr:#06d406"><a href="view_order.php" data-text="&nbsp;View order" class="active" style="font-size:1.2em;">&nbsp;View order&nbsp;</a></li>
            <li style="--clr:#030000"><a href="?log=out" data-text="&nbsp;Log Out">&nbsp;Log Out&nbsp;</a></li>
          </ul>
        </div>
        <div class="clr"></div>
      </div>
    </div>

	<div class="hdbody">
          <div class="abhead">
            <span style="--clr:#06d406;" data-text="Cusomers'"><a>Cusomers'</a></span>
            <span style="left:20px;" style="--clr:#06d406;" data-text="Orders"><a>Orders</a></span>
          </div>
        </div><br>
		<div>
		  <?php
				error_reporting(1);
	
				include("dbconnect.php");
	
				$view = "SELECT * FROM buy";
				$result = mysqli_query($con, $view);
				
				echo "<table border='1' cellspacing='0' cellpadding='15px'>";
				echo "<tr>
						  <th>Brand</th>
					  	  <th>Size</th>
						  <th>Original Price</th>
					  	  <th>Price</th>
					  	  <th>Phone</th>
						  <th>Delivery</th>
						  <th>Address</th>
						  <th>Order_no</th>
					  </tr>
					 ";
				
				while(list($b,$s,$p_or,$p,$phno,$delivery,$add,$order_no) = mysqli_fetch_array($result))
				{
					echo "<tr align='center'>";
					echo "<td>". $b ."</td>";
					echo "<td>". $s ."</td>";
					echo "<td>". $p_or ."</td>";
					echo "<td>". $p ."</td>";
					echo "<td>". $phno ."</td>";
					echo "<td>". $delivery ."</td>";
					echo "<td>". $add ."</td>";
					echo "<td>". $order_no ."</td>";
					echo "</tr>";
				}
				echo "</table>";
		  ?>
		  </div>
		
			<p><a href="home.php">Go Back</a></p>
		
        </div>
        
      
      <div class="clr"></div>
  
  
</body>
</html>
