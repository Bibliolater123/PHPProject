<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>View Products</title>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" href="css/menu-bar.css">
  <link rel="stylesheet" href="css/product.css">
  <!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
  <script type="text/javascript" src="js/cufon-yui.js"></script>
  <script type="text/javascript" src="js/arial.js"></script>
  <script type="text/javascript" src="js/cuf_run.js"></script>
  <!-- CuFon ends -->


</head>

<body>
  <div class="main">

    <div class="header">
      <div class="header_resize">
        <div class="menu-bar menu_resize">
          <ul>
            <li style="--clr:#00ade1"><a href="home.php" data-text="&nbsp;Home"><span><span>&nbsp;Home&nbsp;</span></span></a></li>
            <li style="--clr:#f11313"><a href="insert_product.php" data-text="&nbsp;Add Product"><span><span>&nbsp;Add Product&nbsp;</span></span></a></li>
            <li style="--clr:#ffdd1c"><a href="view_product.php" data-text="&nbsp;View Products" class="active" style="font-size:1.2em;"><span><span>&nbsp;View Products&nbsp;</span></span></a></li>
            <li style="--clr:#dc00d4"><a href="feedback.php" data-text="&nbsp;View feedback">&nbsp;View feedback&nbsp;</a></li>
            <li style="--clr:#06d406"><a href="view_order.php" data-text="&nbsp;View order">&nbsp;View order&nbsp;</a></li>
            <li style="--clr:#030000"><a href="?log=out" data-text="&nbsp;Log Out">&nbsp;Log Out&nbsp;</a></li>
          </ul>
        </div>
        <div class="clr"></div>
      </div>
    </div>

            <div class="hdbody">
          <div class="abhead">
            <span style="--clr:#ffdd1c;" data-text="Your"><a>Your</a></span>
            <span style="left:20px;" style="--clr:#ffdd1c;" data-text="Products"><a>Products</a></span>
          </div>
        </div><br>
            <?php
            error_reporting(1);

            include("dbconnect.php");

            $view = "SELECT * FROM product";
            $result = mysqli_query($con, $view);

            echo "<table style='--t_c:#ffdd1c' border='1' cellspacing='0' cellpadding='5px' >";
            echo "<tr>
						  <th class='p_id'>Product id</th>
					  	  <th class='p_brands'>Product brands</th>
					  	  <th class='p_size'>Product size</th>
                <th class='p_or_cost'>Product original price</th>
					  	  <th class='p_price'>Product price</th>
					  	  <th class='p_img'>Product image</th>
					  	  <th class='p_desc'>Product description</th>
                <th class='p_delete'>Delete</th>
					  </tr>
					 ";

            while (list($p_id, $p_brands, $p_size, $p_or_cost, $p_price, $p_img, $p_desc) = mysqli_fetch_array($result)) {
              echo "<tr align='center'>";
              echo "<td class='p_id'>" . $p_id . "</td>";
              echo "<td class='p_brands'>" . $p_brands . "</td>";
              echo "<td class='p_size'>" . $p_size . "</td>";
              echo "<td class='p_or_cost'>" . $p_or_cost . "</td>";
              echo "<td class='p_price'>" . $p_price . "</td>";
              echo "<td class='p_img'>" . "<img src='product_images/$p_img' width='80px' height='70px'" . "</td>";
              echo "<td class='p_desc'>" . $p_desc . "</td>";

              echo "<td class='p_delete'>" . "<a href='delete.php?pro_id=$p_id & pro_img=$p_img' class='delete'>Delete</a>" . "</td>";
              echo "</tr>";
            }
            echo "</table>";
            ?>
 
  </div>
</body>

</html>