<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Feedback</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="adminstyle.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/menu-bar.css">
<link rel="stylesheet" href="css/feedback.css">
<!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/arial.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>
<!-- CuFon ends -->



</head>
<body>
<div class="main">

  <div class="header">
      <div class="header_resize">
        <div class="menu-bar menu_resize">
          <ul>
            <li style="--clr:#00ade1"><a href="home.php" data-text="&nbsp;Home"><span><span>&nbsp;Home&nbsp;</span></span></a></li>
            <li style="--clr:#f11313"><a href="insert_product.php" data-text="&nbsp;Add Product"><span><span>&nbsp;Add Product&nbsp;</span></span></a></li>
            <li style="--clr:#ffdd1c"><a href="view_product.php" data-text="&nbsp;View Products"><span><span>&nbsp;View Products&nbsp;</span></span></a></li>
            <li style="--clr:#dc00d4"><a href="feedback.php" data-text="&nbsp;View feedback" class="active" style="font-size:1.2em;">&nbsp;View feedback&nbsp;</a></li>
            <li style="--clr:#06d406"><a href="view_order.php" data-text="&nbsp;View order">&nbsp;View order&nbsp;</a></li>
            <li style="--clr:#5613f1"><a href="?log=out" data-text="&nbsp;Log Out">&nbsp;Log Out&nbsp;</a></li>
          </ul>
        </div>
        <div class="clr"></div>
      </div>
    </div>

    
          <div class="hdbody">
          <div class="abhead">
          <div class="feedback_error_space"></div>
            <span style="--clr:#dc00d4;" data-text="Customers'"><a>Customers'</a></span>
            <span style="left:20px;" style="--clr:#dc00d4;" data-text="Feedbacks"><a>Feedbacks</a></span>
          </div>
        </div><br>
		  <?php
				error_reporting(1);
	
				include("dbconnect.php");
	
				$view = "SELECT * FROM feedback";
				$result = mysqli_query($con, $view);
				
				echo "<table border='1' cellspacing='0' cellpadding='15px'>";
				echo "<tr>
						  <th>Email</th>
					  	  <th>Phone</th>
					  	  <th>Message</th>
					  	 
					  </tr>
					 ";
				
				while(list($eadd, $ph, $msg) = mysqli_fetch_array($result))
				{
					echo "<tr>";
					echo "<td>". $eadd ."</td>";
					echo "<td>". $ph ."</td>";
					echo "<td>". $msg ."</td>";
					echo "</tr>";
				}
				echo "</table>";
		  ?>
		  
			<p><a href="home.php">Go Back</a></p>
			
        
      
      <div class="clr"></div>

  
  
</div>
</body>
</html>
