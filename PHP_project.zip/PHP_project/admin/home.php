<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Home</title>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" href="css/menu-bar.css">
  <link rel="stylesheet" href="css/moonwalk.css">
  <link rel="stylesheet" href="welcome/style.css">
  <!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
  <script type="text/javascript" src="js/cufon-yui.js"></script>
  <script type="text/javascript" src="js/arial.js"></script>
  <script type="text/javascript" src="js/cuf_run.js"></script>
  <!-- CuFon ends -->
  <?php
  error_reporting(1);
  if ($_REQUEST['log'] == 'out') {
    session_destroy();
    header("location:index.php");
  }
  ?>
</head>

<body>
  <div class="main">

    <div class="header">
      <div class="header_resize">
        <div class="menu-bar menu_resize">
          <ul>
            <li style="--clr:#00ade1"><a href="home.php" data-text="&nbsp;Home" class="active" style="font-size:1.2em;"><span><span>&nbsp;Home&nbsp;</span></span></a></li>
            <li style="--clr:#f11313"><a href="insert_product.php" data-text="&nbsp;Add Product"><span><span>&nbsp;Add Product&nbsp;</span></span></a></li>
            <li style="--clr:#ffdd1c"><a href="view_product.php" data-text="&nbsp;View Products"><span><span>&nbsp;View Products&nbsp;</span></span></a></li>
            <li style="--clr:#dc00d4"><a href="feedback.php" data-text="&nbsp;View feedback">&nbsp;View feedback&nbsp;</a></li>
            <li style="--clr:#06d406"><a href="view_order.php" data-text="&nbsp;View order">&nbsp;View order&nbsp;</a></li>
            <li style="--clr:#030000"><a href="?log=out" data-text="&nbsp;Log Out">&nbsp;Log Out&nbsp;</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>

<div class="clr"></div>
    <div class="centered">
    <div class="welcome">
  <ul>
        <li>
          <input type="checkbox" />
          <div>W</div>
        </li>
        <li>
          <input type="checkbox" />
          <div>E</div>
        </li>
        <li>
          <input type="checkbox" />
          <div>L</div>
        </li>
        <li>
          <input type="checkbox" />
          <div>C</div>
        </li>
        <li>
          <input type="checkbox" />
          <div>O</div>
        </li>
        <li>
          <input type="checkbox" />
          <div>M</div>
        </li>
        <li>
          <input type="checkbox" />
          <div>E</div>
        </li>
        <li>
          <input type="checkbox" />
          <div>!</div>
        </li>
    </ul>
    </div>
    <div class="mj">
      <div class="full-head">
        <div class="hat"></div>
        <div class="hat-part"></div>
        <div class="m-head"></div>
      </div>
      <div class="m-body"></div>
      
      <div class="arms">
        <div class="arm"></div>
        <div class="arm-right"></div>
        <div class="arm-left"></div>
      </div>
      
      <div class="legs">
          <div class="leg-right">
            <div class="upper-right"></div>
             <div class="lower-right"></div>
          </div>
          <div class="leg-left">
             <div class="upper-left"></div>
             <div class="lower-left"></div>
          </div>
      </div>
      
      <div class="foot">
        <div class="feet feet-right"></div>
        <div class="feet feet-left"></div>
      </div>
     
    </div>  
</div>

    
</body>

</html>