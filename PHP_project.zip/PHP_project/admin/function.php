<?php
	
	$con = mysqli_connect("localhost","root","","bootshop");

	//getting the brands from brands table.
	function getBrands()
	{
		global $con;
		$get_brand = "SELECT * FROM brands";
		$run_brand = mysqli_query($con,$get_brand);
		while($row_brand = mysqli_fetch_array($run_brand))
		{
			$b_id = $row_brand['b_id'];
			$b_title = $row_brand['b_title'];
			echo "<li><a href='index.php?brand=$b_title'>$b_title</a></li>";
		}
	}

	//getting the products from product table.
	function getProduct()
	{
	  if(!isset($_GET['brand']))
	  {
		global $con;
		$get_pro = "SELECT * FROM product order by rand()";
		$run_pro = mysqli_query($con,$get_pro);
		while($row_pro = mysqli_fetch_array($run_pro))
		{ 
			$pro_id = $row_pro['p_id'];
			$pro_brand = $row_pro['p_brand'];
			$pro_size = $row_pro['p_size'];
			$pro_or_cost = $row_pro['p_or_cost'];
			$pro_price = $row_pro['p_price'];
			$pro_image = $row_pro['p_image'];
			echo " 
			<div>
			<h1>$pro_size</h1>
			<article class='card'>
					
				<div class='card__img'>
				<img src='admin/product_images/$pro_image'><br>
				</div>
					
				<div class='card__name'>
				<p>$pro_brand</p>
				</div>
					
				<div class='card__precis'>
				<a href='add_favorite.php?pro_id=<?php echo $pro_id; ?>' class='card__icon' style='--accent-color:#00ade1'>
					<ion-icon name='heart'></ion-icon>
				</a>
				<div>
    																			<div class='or_cost_line'></div>
				<span class='card__preci card__preci--now'>$pro_or_cost</span>
					<span class='card__preci card__preci--now'>$pro_price</span>
				</div>
				<a href='#' class='card__icon'>
					<ion-icon name='cart'></ion-icon>
					</a>
				</div>
				<a href='detail.php?pro_id=$pro_id' style='float:left;margin-left:15px;'> Details </a>
				<a href='login.php?buy_pro=$pro_id' ><button style='float:right;margin-right:25px;'> Buy </button> </a>
			</div>
			</article>
			<script src='https://unpkg.com/ionicons@5.0.0/dist/ionicons.js'></script>
			
			
			
			";

		}
	  }
	}
	
	function getBrandPro()
	{
	  if(isset($_GET['brand']))
	  {
		global $con;
		$brand_title = $_GET['brand'];
		$get_brand_pro = "SELECT * FROM product WHERE p_brand='$brand_title'";
		$run_brand_pro = mysqli_query($con,$get_brand_pro);
		while($row_brand_pro = mysqli_fetch_array($run_brand_pro))
		{ 
			$pro_id = $row_brand_pro['p_id'];
			$pro_brand = $row_brand_pro['p_brand'];
			$pro_size = $row_brand_pro['p_size'];
			$pro_or_cost = $row_brand_pro['p_or_cost'];
			$pro_price = $row_brand_pro['p_price'];
			$pro_image = $row_brand_pro['p_image'];
			echo " 
			<div>
			<h1>$pro_size</h1>
			<article class='card'>
					
				<div class='card__img'>
				<img src='admin/product_images/$pro_image'><br>
				</div>
					
				<div class='card__name'>
				<p>$pro_brand</p>
				</div>
					
				<div class='card__precis'>
				<a href='#' class='card__icon'>
					<ion-icon name='heart'></ion-icon>
				</a>
				<div>
				<span class='card__preci card__preci--now'><del style='color: red;'>$pro_or_cost</del></span>
					<span class='card__preci card__preci--now'>$pro_price</span>
				</div>
				<a href='#' class='card__icon'>
					<ion-icon name='cart'></ion-icon>
					</a>
				</div>
				<a href='detail.php?pro_id=$pro_id' style='float:left;margin-left:15px;'> Details </a>
				<a href='login.php?buy_pro=$pro_id' ><button style='float:right;margin-right:25px;'> Buy </button> </a>
					
						
			</div>
			</article>
			<script src='https://unpkg.com/ionicons@5.0.0/dist/ionicons.js'></script>
			
			
			
			";
			
		}
	  }
	}
	
?>
