<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Insert Product</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="css/menu-bar.css">
<link rel="stylesheet" href="css/add_product.css">
<!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/arial.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>
<!-- CuFon ends -->

<?php
	error_reporting(1);
	
	include("dbconnect.php");
	
	if(isset($_POST['insert']))
	{
		
		$p_brands = $_POST['p_brands'];
		$p_size = $_POST['p_size'];
		$p_or_cost = $_POST['p_or_cost'];
		$p_price = $_POST['p_price'];
		$p_desc = $_POST['p_desc'];
		
		$p_img = $_FILES['p_img']['name'];
		
		
		
		move_uploaded_file($_FILES['p_img']['tmp_name'],"product_images/$p_img");
		
		$insert_p = "INSERT INTO product VALUES('','$p_brands','$p_size','$p_or_cost','$p_price','$p_img','$p_desc')";
		$query = mysqli_query($con,$insert_p);
		echo "<script>alert('Product has been successfully inserted into the database.')</script>";
		echo "<script>window.open('insert_product.php','_self')</script>";	
			
		
	}
?>

</head>
<body>
<div class="main">

  <div class="header">
      <div class="header_resize">
        <div class="menu-bar menu_resize">
          <ul>
            <li style="--clr:#00ade1"><a href="home.php" data-text="&nbsp;Home"><span><span>&nbsp;Home&nbsp;</span></span></a></li>
            <li style="--clr:#f11313"><a href="insert_product.php" data-text="&nbsp;Add Product" class="active" style="font-size:1.2em;"><span><span>&nbsp;Add Product&nbsp;</span></span></a></li>
            <li style="--clr:#ffdd1c"><a href="view_product.php" data-text="&nbsp;View Products"><span><span>&nbsp;View Products&nbsp;</span></span></a></li>
			<li style="--clr:#dc00d4"><a href="feedback.php" data-text="&nbsp;View feedback">&nbsp;View feedback&nbsp;</a></li>
            <li style="--clr:#06d406"><a href="view_order.php" data-text="&nbsp;View order">&nbsp;View order&nbsp;</a></li>
            <li style="--clr:#030000"><a href="?log=out" data-text="&nbsp;Log Out">&nbsp;Log Out&nbsp;</a></li>
          </ul>
        </div>
        <div class="clr"></div>
      </div>
    </div>

	<div class="hdbody">
          <div class="abhead">
            <span style="--clr:#f11313;" data-text="Your"><a>Your</a></span>
            <span style="left:20px;" style="--clr:#f11313;" data-text="Products"><a>Products</a></span>
          </div>
        </div><br>
		  <form method="post" action="insert_product.php" enctype="multipart/form-data">
			<table border="0" cellpadding="10px" align="center" style="font-size:16px; font-weight:bold;">
				
				<tr>
					<td>Product Brands</td>
					<td>
						<select name="p_brands" required>
							<option>Select brands</option>
							<?php
								$get_brand = "SELECT * FROM brands";
								$run_brand = mysqli_query($con,$get_brand);
								while($row_brand = mysqli_fetch_array($run_brand))
								{
									$b_id = $row_brand['b_id'];
									$b_title = $row_brand['b_title'];
									echo "<option value='$b_title'>$b_title</a></li>";
								}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td>Product Size</td>
					<td><input type="text" name="p_size" required></td>
				</tr>
				<tr>
					<td>Product Original Price</td>
					<td><input type="text" name="p_or_cost" required></td>
				</tr>
				<tr>
					<td>Product Price</td>
					<td><input type="text" name="p_price" required></td>
				</tr>
				<tr>
					<td>Product Image</td>
					<td><input type="file" name="p_img" required></td>
				</tr>
				<tr>
					<td>Product Description</td>
					<td><textarea name="p_desc" cols="20"  rows="10" required></textarea></td>
				</tr>
				<tr>
					<td colspan="2" align="center"><input type="submit" name="insert" value="Insert Product"></td>
				</tr>
			</table>
		  </form>
        
      
      <div class="clr"></div>

  
  
</div>
</body>
</html>
